package ex6_7;

public abstract class Musica {

	private double durada;
	public abstract void reproduir();
	public Musica() {
		
	}
	
	public Musica(double durada) {
		
		this.durada = durada;
	}
	
	
	
	
	
}
