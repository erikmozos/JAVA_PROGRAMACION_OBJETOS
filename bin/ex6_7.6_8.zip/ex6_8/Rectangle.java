package ex6_8;

public class Rectangle extends Figura {

	@Override
	void dibuixar() {
	System.out.println("Dibuixant rectangle");
	}
	
}
