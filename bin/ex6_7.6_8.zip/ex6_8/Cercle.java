package ex6_8;

public class Cercle extends Figura {
	
	@Override
	void dibuixar() {
	System.out.println("Dibuixant cercle");
	}

}
