package ex6_5;

public class Persona {
	
	String nom;
	String dni;
	int edat;
	
	public Persona() {
		
	}
	
	public Persona(String nom, String dni, int edat) {
		super();
		this.nom = nom;
		this.dni = dni;
		this.edat = edat;
	}
	
	

}
