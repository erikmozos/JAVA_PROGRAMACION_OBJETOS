package ex6_6;

public class Auriculars {

	String marca;
	String model;
	String color;
	
	
	public Auriculars() {
		
	}


	public Auriculars(String marca, String model, String color) {
		
		this.marca = marca;
		this.model = model;
		this.color = color;
	}
	
	
	
}
