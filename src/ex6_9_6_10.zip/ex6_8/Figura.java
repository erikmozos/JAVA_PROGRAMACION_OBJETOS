package ex6_8;

public abstract class Figura {

	void dibuixar() {
		System.out.println("Dibuixar");
		}
}
